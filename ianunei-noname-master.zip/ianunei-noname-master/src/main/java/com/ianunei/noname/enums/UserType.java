package com.ianunei.noname.enums;

/**
 * @author 帅小鸦
 * @date 2022/5/12
 */

public enum UserType {
    ADMIN, USER
}
